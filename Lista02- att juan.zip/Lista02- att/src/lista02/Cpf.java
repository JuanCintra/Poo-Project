/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

import java.math.BigInteger;
import java.util.Scanner;

/**
 *
 * @author isagu
 */
public class Cpf {
    
BigInteger cpf;


//Validar CPF
    public void  inserirCpf(){
     int loop=0;
        System.out.println("Insira o CPF (somente números): ");
        
        while(loop==0){
          int  loop1=1;
         while(loop1==1){   
        Scanner entrada= new Scanner(System.in);
        cpf= entrada.nextBigInteger();
        String biStr = cpf.toString();
      int[] cpf1 = new int[biStr.length()];
      for(int i=0; i<biStr.length(); i++) {
      cpf1[i] = Integer.parseInt(String.valueOf(biStr.charAt(i)));
}
      int length = biStr.length();
      
      if(length<11 || length>11){
          
          System.out.println("O cpf deve conter 11 dígitos. Insira novamente:\n");
      }
      else{
          loop1++;
          break;
      }
        }
        int k=0,cpfigual=0;
        int a=0,b=0,c=0,d=0,e=0,f=0,g=0,h=0,l=0,j=0;
        
      String biStr = cpf.toString();
      int[] cpf1 = new int[biStr.length()];
      for(int i=0; i<biStr.length(); i++) {
      cpf1[i] = Integer.parseInt(String.valueOf(biStr.charAt(i)));
}
      int length = biStr.length();
    
      if(length<11 || length>11){
          System.out.println("O cpf deve conter 11 dígitos.\n");
      }
      while(k<length){
        
        if(cpf1[k]==0){
              a++;
          }
          if(cpf1[k]==1){
              b++;
          }
          if(cpf1[k]==2){
              c++;
          }
          if(cpf1[k]==3){
              d++;
          }
          if(cpf1[k]==4){
              e++;
          }
          if(cpf1[k]==5){
              f++;
          }
          if(cpf1[k]==6){
              g++;
          }
          if(cpf1[k]==7){
              h++;
          }
          if(cpf1[k]==8){
              l++;
          }
          if(cpf1[k]==9){
              j++;
          }
    
          if(a==11||b==11||c==11||d==11||e==11||f==11||g==11||h==11||l==11||j==11){
              cpfigual=1;
              System.out.println("O cpf não pode conter todo os dígitos iguais!");
              
          }
          
          k++;
      }
        
        int y=11,z=0;
        b=12;
        c=0;
        
        for(int x=0;x<=8;x++){
            y--;
            int digitoA=0, mult=0;
            mult=cpf1[x]*y;
            z=z+mult;
            
            if(x==8){
            digitoA=11-(z%11);
            if(digitoA>=10){
                digitoA=0;
            }
                if(digitoA==cpf1[9] && cpfigual!=1){
                    for(a=0;a<=9;a++){
                    b--;
                    int mult2=0,digitoB=0;
                    mult2=cpf1[a]*b;
                    c=c+mult2;
                    
                    
                    if(a==9){
                    digitoB=11-(c%11);
                    if(digitoB>=10){
                        digitoB=0;
                    }
                    if(digitoB==cpf1[10] && cpfigual!=1){
                        System.out.println("Cpf Válido!!\n");
                        loop=1;
                        break;
                    }
                    else if(digitoB!=cpf1[10] && a==9){
                        System.out.println("Cpf Inválido!! Insira Novamente:\n");
                        break;
                    }
                    if(a==9){
                        break;
                    }
                    }
                
            }
            }
                else{
                    if(cpfigual==1){
                        System.out.println("Insira Novamente:\n");
                    }
                    else{
                    System.out.println("Cpf Inválido!! Insira Novamente:\n");
                    }
                }
            }
        }
        }
        }    

}
